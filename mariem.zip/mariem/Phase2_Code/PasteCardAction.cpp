#include "PasteCardAction.h"
#include "Grid.h"
#include "Input.h"
#include "Output.h"
#include "CardOne.h"
#include "CardTwo.h"
#include "CardThree.h"
#include "CardFour.h"
#include "CardFive.h"
#include "CardSix.h"
#include "CardSeven.h"
#include "CardEight.h"
#include "CardNine.h"
#include "CardTen.h"
#include "CardEleven.h"
#include "CardTwelve.h"
#include "CardThirteen.h"
#include "CardFourteen.h"


PasteCardAction::PasteCardAction(ApplicationManager* pApp) : Action(pApp)
{
	// Initializes the pManager pointer of Action with the passed pointer
}

PasteCardAction::~PasteCardAction()
{
}

void PasteCardAction::ReadActionParameters()
{

	// 1- Get a Pointer to the Input / Output Interfaces
	Grid* pGrid = pManager->GetGrid();
	Output* pOut = pGrid->GetOutput();
	Input* pIn = pGrid->GetInput();

	// 2- Read the "cardPosition" parameter (its cell position) 
	pOut->PrintMessage("Click on the destination cell.");
	newCardPosition = pIn->GetCellClicked();
	// Clear status bar
	pOut->ClearStatusBar();
}

void PasteCardAction::Execute()
{
	ReadActionParameters();
	Card* pCard = NULL; // will point to the card object type
	Grid* pGrid = pManager->GetGrid();
	pCard = pGrid->HasCard(newCardPosition);
	
	if (pCard != NULL)
		pGrid->PrintErrorMessage("You've clicked on a cell that already contains a CARD!..click to continue..");
	
	else
	{
		pCard = pGrid->GetClipboard();
		pCard->setposition(newCardPosition);
		pGrid->AddObjectToCell(pCard);
		Card::CountCard++;
	}
}



//pCard = pGrid->GetClipboard();
	//int CardNumber=pCard->GetCardNumber();
	//if (CardNumber == 1)
	//{
	//	int data = pCard->getCardData();
	//	pNewCard = new CardOne(newCardPosition);
	//	pNewCard->setCardData(data);
	//	pGrid->AddObjectToCell(pNewCard);
	//}
	//else if (CardNumber == 2)
	//{
	//	int data = pCard->getCardData();
	//	pCard = new CardTwo(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 3)
	//{
	//	pCard = new CardThree(newCardPosition);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 4)
	//{
	//	pCard = new CardFour(newCardPosition);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 5)
	//{
	//	pCard = new CardFive(newCardPosition);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 6)
	//{
	//	pCard = new CardSix(newCardPosition);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 7)
	//{
	//	pCard = new CardSeven(newCardPosition);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 8)
	//{
	//	pCard = new CardEight(newCardPosition);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//
	//else if (CardNumber == 9)
	//{ ////FEH MOSHKELA HENA
	//	int data = pCard->getCardData();
	//	pCard = new CardNine(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 10)
	//{
	//	int data = pCard->getCardData();
	//	pCard = new CardTen(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 11)
	//{
	//	int data = pCard->getCardData();
	//	pCard = new CardEleven(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 12)
	//{
	//	int data = pCard->getCardData();
	//	pCard = new CardTwelve(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 13)
	//{
	//	int data = pCard->getCardData();
	//	pCard = new CardThirteen(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}
	//else if (CardNumber == 14)
	//{
	//	int data = pCard->getCardData();
	//	pCard = new CardFourteen(newCardPosition);
	//	pCard->setCardData(data);
	//	pGrid->AddObjectToCell(pCard);
	//}